package net.shyshkin.study.batch.exception;

public class EntityNotFoundException extends RuntimeException {
}
