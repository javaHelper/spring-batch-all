package net.shyshkin.study.batch.resilience.exception;

public class ServiceWrongStatusException extends RuntimeException {
}
