package net.shyshkin.study.batch.resilience.exception;

public class Service404Exception extends RuntimeException {
}
