drop table reviews;
drop table products_jpa;
drop table products_jpa_out;
drop table categories;