insert into products (prod_id, prod_name, prod_desc, price, unit)
values (1, 'Apple DB', 'apple cell phone', 500.00, 10);
insert into products (prod_id, prod_name, prod_desc, price, unit)
values (2,'Dell DB','dell computer',3000,5);
insert into products (prod_id, prod_name, prod_desc, price, unit)
values (3,'office DB','ms office software',196,23);