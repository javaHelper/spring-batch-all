package net.shyshkin.study.batch.faulttolerance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaultToleranceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FaultToleranceApplication.class, args);
    }

}
