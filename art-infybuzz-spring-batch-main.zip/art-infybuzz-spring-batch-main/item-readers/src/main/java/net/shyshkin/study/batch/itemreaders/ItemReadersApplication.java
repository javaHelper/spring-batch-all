package net.shyshkin.study.batch.itemreaders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItemReadersApplication {

    public static void main(String[] args) {
        SpringApplication.run(ItemReadersApplication.class, args);
    }

}
